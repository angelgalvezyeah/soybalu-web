import "../globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Términos y Condiciones — balu",
  description: "Términos y condiciones de uso de balu, app de finanzas personales desarrollada por Grupo Bastión.",
};

export default function TerminosPage() {
  const S = {
    container: { maxWidth: 720, margin: "0 auto", padding: "0 24px" } as React.CSSProperties,
  };

  const sections = [
    {
      num: "01",
      title: "Descripción del servicio",
      content: `balu es una aplicación de gestión de finanzas personales que te permite registrar cuentas, movimientos, presupuestos y gastos recurrentes de forma manual, y opcionalmente importar estados de cuenta bancarios en PDF con ayuda de inteligencia artificial.

El servicio opera bajo modelo de suscripción:
• balu Lite: $69/mes o $499/año (ahorra ~40%)
• balu Pro: $129/mes o $999/año (ahorra ~36%)

Los precios están expresados en pesos mexicanos (MXN).`,
    },
    {
      num: "02",
      title: "Registro y cuenta",
      content: `Para usar balu debes crear una cuenta con nombre, correo electrónico válido y contraseña. Eres responsable de:

• Mantener la confidencialidad de tus credenciales.
• Toda la actividad que ocurra bajo tu cuenta.
• Notificarnos de inmediato si sospechas un acceso no autorizado.

Tu sesión se gestiona mediante tokens JWT almacenados de forma segura en tu dispositivo. No está permitido compartir tu cuenta con terceros.`,
    },
    {
      num: "03",
      title: "Suscripción y pagos",
      content: `Al suscribirte a balu Lite o balu Pro aceptas lo siguiente:

• El cobro se realiza de forma anticipada (mensual o anual) a través de Google Play o App Store.
• La suscripción se renueva automáticamente al final de cada período salvo que la canceles antes del vencimiento.
• Los precios pueden ajustarse con al menos 30 días de aviso previo.`,
    },
    {
      num: "04",
      title: "Cancelaciones y reembolsos",
      content: `Puedes cancelar tu suscripción en cualquier momento desde la configuración de tu cuenta en Google Play o App Store:

• Mantendrás acceso hasta el fin del período pagado (mensual o anual).
• No se realizan reembolsos proporcionales por períodos no utilizados, salvo lo que exija la legislación mexicana o las políticas de la tienda.

⚠️ Eliminar la app no cancela tu suscripción. La cancelación debe realizarse desde la tienda donde realizaste la compra.`,
    },
    {
      num: "05",
      title: "Funciones con Inteligencia Artificial",
      content: `balu utiliza la API de Anthropic (Claude) en dos funciones opcionales:

• Importación de PDFs: el contenido de tu estado de cuenta bancario es enviado a Anthropic para extraer los movimientos automáticamente. balu no almacena el PDF tras el procesamiento.

• Insight del dashboard: datos agregados de tu mes (totales de ingresos, gastos, top 3 categorías y tu primer nombre) son enviados a la API de Anthropic para generar tu resumen mensual. No se envían movimientos individuales.

Al usar estas funciones aceptas que tus datos sean procesados por Anthropic conforme a su propia política de privacidad.`,
    },
    {
      num: "06",
      title: "Exportación de datos y archivos",
      content: `balu te permite:

• Exportar a Excel: generar un archivo con tus movimientos del mes directamente en tu dispositivo. El proceso es local — no pasa por nuestros servidores.

• Importar PDFs manualmente: seleccionar un archivo PDF desde tu dispositivo o recibirlo compartido desde otra app. balu accede únicamente al archivo que tú seleccionas explícitamente.`,
    },
    {
      num: "07",
      title: "Uso permitido y prohibiciones",
      content: `balu está diseñada para uso personal y legítimo. Queda prohibido:

• Usar la app para actividades ilegales o fraudulentas.
• Intentar acceder, modificar o dañar los servidores de balu.
• Realizar ingeniería inversa o intentar extraer el código fuente.
• Usar la app para registrar datos financieros de terceros sin su consentimiento.
• Automatizar peticiones a nuestra API sin autorización expresa.`,
    },
    {
      num: "08",
      title: "Propiedad intelectual",
      content: `Todos los derechos sobre balu — incluyendo código, diseño, nombre, logotipo y mascota — son propiedad exclusiva de Grupo Bastión. Se te otorga una licencia limitada, personal y no transferible para usar la app conforme a estos términos.`,
    },
    {
      num: "09",
      title: "Limitación de responsabilidad",
      content: `balu es una herramienta de registro personal. No somos una institución financiera ni ofrecemos asesoría financiera, fiscal o de inversión.

• No nos responsabilizamos por decisiones tomadas con base en la información registrada en la app.
• No garantizamos disponibilidad ininterrumpida.
• La precisión de los datos importados por PDF depende de la calidad del documento y del procesamiento de IA.
• En la máxima medida permitida por la ley, nuestra responsabilidad total no excederá el monto pagado en los últimos 3 meses de suscripción.`,
    },
    {
      num: "10",
      title: "Modificaciones al servicio y términos",
      content: `Nos reservamos el derecho de modificar, suspender o descontinuar cualquier aspecto del servicio. Para cambios materiales en estos términos, notificaremos con al menos 15 días de anticipación. El uso continuo implica aceptación de los términos actualizados.`,
    },
    {
      num: "11",
      title: "Terminación de cuenta",
      content: `Puedes eliminar tu cuenta desde Ajustes en la app. Grupo Bastión puede suspender cuentas que violen estos términos o en caso de actividad fraudulenta. Los datos serán tratados conforme a nuestra Política de Privacidad.`,
    },
    {
      num: "12",
      title: "Ley aplicable y jurisdicción",
      content: `Estos términos se rigen por las leyes de los Estados Unidos Mexicanos. Cualquier controversia se someterá a los tribunales competentes de Saltillo, Coahuila, México.`,
    },
  ];

  return (
    <>
      {/* Nav simple */}
      <nav style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        background: "rgba(10,10,10,0.9)", backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)", height: 60,
        display: "flex", alignItems: "center",
      }}>
        <div style={{ ...S.container, display: "flex", alignItems: "center", gap: 12, width: "100%" }}>
          <a href="/" style={{ display: "flex", alignItems: "center", gap: 8, textDecoration: "none" }}>
            <div style={{ width: 28, height: 28, background: "linear-gradient(135deg, #10B981, #059669)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>🐻</div>
            <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#F5F5F0", fontSize: 16 }}>balu</span>
          </a>
          <span style={{ color: "#6B6B63", fontSize: 13 }}>/ Términos y Condiciones</span>
        </div>
      </nav>

      <main style={{ paddingTop: 100, paddingBottom: 80 }}>
        <div style={S.container}>
          {/* Header */}
          <div style={{ textAlign: "center", marginBottom: 56 }}>
            <span style={{ display: "inline-block", background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)", color: "#6EE7B7", fontSize: 11, fontWeight: 700, padding: "4px 12px", borderRadius: 100, marginBottom: 16, letterSpacing: "1px", fontFamily: "'Syne', sans-serif" }}>
              VIGENTE DESDE ENERO 2026
            </span>
            <h1 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(32px, 5vw, 48px)", fontWeight: 800, letterSpacing: "-1.5px", marginBottom: 16 }}>
              Términos y Condiciones
            </h1>
            <p style={{ fontSize: 16, color: "#A3A39B", lineHeight: 1.6 }}>
              balu — App de finanzas personales desarrollada por <strong style={{ color: "#F5F5F0" }}>Grupo Bastión</strong>
            </p>
          </div>

          {/* Intro */}
          <div style={{
            background: "#111111",
            border: "1px solid rgba(16,185,129,0.15)",
            borderRadius: 16,
            padding: 24,
            marginBottom: 32,
          }}>
            <p style={{ fontSize: 15, color: "#A3A39B", lineHeight: 1.7 }}>
              Estos Términos y Condiciones regulan el acceso y uso de <strong style={{ color: "#F5F5F0" }}>balu</strong>, aplicación de finanzas personales desarrollada por <strong style={{ color: "#F5F5F0" }}>Grupo Bastión</strong>, con sede en Saltillo, Coahuila, México. Al descargar, instalar o usar balu, aceptas quedar vinculado por estos términos. Si no estás de acuerdo, no uses la aplicación.
            </p>
          </div>

          {/* Sections */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {sections.map((section, i) => (
              <div key={i} style={{
                background: "#111111",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: 16,
                padding: "24px 28px",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                  <div style={{
                    width: 28, height: 28,
                    background: "#10B981",
                    borderRadius: "50%",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 11, fontWeight: 800, color: "#fff",
                    fontFamily: "'Syne', sans-serif",
                    flexShrink: 0,
                  }}>
                    {section.num}
                  </div>
                  <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 17, fontWeight: 700, color: "#F5F5F0" }}>
                    {section.title}
                  </h2>
                </div>
                <div style={{ paddingLeft: 40 }}>
                  {section.content.split("\n\n").map((para, j) => (
                    <p key={j} style={{ fontSize: 14, color: "#A3A39B", lineHeight: 1.7, marginBottom: j < section.content.split("\n\n").length - 1 ? 12 : 0, whiteSpace: "pre-line" }}>
                      {para}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Contact */}
          <div style={{
            background: "rgba(16,185,129,0.06)",
            border: "1px solid rgba(16,185,129,0.2)",
            borderRadius: 16,
            padding: 28,
            marginTop: 32,
            textAlign: "center",
          }}>
            <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 16, fontWeight: 700, color: "#10B981", marginBottom: 8 }}>
              ¿Tienes preguntas sobre estos términos?
            </p>
            <p style={{ fontSize: 14, color: "#6EE7B7", marginBottom: 4 }}>
              Escríbenos a <a href="mailto:legal@grupobastión.com" style={{ color: "#10B981" }}>legal@grupobastión.com</a>
            </p>
            <p style={{ fontSize: 13, color: "#6B6B63" }}>Grupo Bastión — Saltillo, Coahuila, México</p>
          </div>
        </div>
      </main>

      <footer style={{ borderTop: "1px solid rgba(255,255,255,0.05)", padding: "24px 0", textAlign: "center" }}>
        <p style={{ fontSize: 12, color: "#6B6B63" }}>
          © 2026 Grupo Bastión. Todos los derechos reservados. balu es una marca de Grupo Bastión.
        </p>
      </footer>
    </>
  );
}
