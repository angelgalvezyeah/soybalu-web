import "../globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Política de Privacidad — balu",
  description: "Política de privacidad de balu, app de finanzas personales desarrollada por Grupo Bastión.",
};

export default function PrivacidadPage() {
  const S = {
    container: { maxWidth: 720, margin: "0 auto", padding: "0 24px" } as React.CSSProperties,
  };

  const sections = [
    {
      num: "01",
      title: "Información que recopilamos",
      content: `Para brindarte el servicio de balu, recopilamos únicamente la información que tú introduces directamente:

• Datos de cuenta: nombre, correo electrónico y contraseña (almacenada con cifrado seguro, nunca en texto plano).
• Datos financieros personales: cuentas, movimientos, presupuestos, gastos recurrentes y saldos iniciales que tú mismo registras.
• Entidades: nombre, descripción y moneda de las entidades financieras que crees.
• PDFs bancarios (opcional): si usas la función de importación, el PDF es enviado temporalmente a la API de Anthropic. No es almacenado por balu tras el procesamiento.
• Resumen financiero mensual: datos agregados del mes (totales de ingresos, gastos, top 3 categorías y tu primer nombre) para el insight de IA.
• Progreso de onboarding: indicador de los pasos del tutorial completados.
• Preferencias locales: token de sesión y preferencias de visualización guardados en tu dispositivo.

✅ balu NO recopila contraseñas bancarias, no rastrea tu ubicación, no usa cámara ni micrófono, no accede a contactos, y no implementa sistemas de analíticas de terceros.`,
    },
    {
      num: "02",
      title: "Cómo usamos tu información",
      content: `Usamos tu información exclusivamente para:

• Proveer y mantener el funcionamiento de la app balu.
• Autenticar tu sesión de forma segura mediante tokens JWT.
• Sincronizar tus datos financieros entre tus dispositivos.
• Procesar la importación de PDFs bancarios con ayuda de inteligencia artificial.
• Gestionar tu suscripción (balu Lite o balu Pro).
• Atender solicitudes de soporte técnico.

No usamos tus datos financieros para publicidad, análisis de crédito, scoring financiero, ni los compartimos con terceros para fines comerciales.`,
    },
    {
      num: "03",
      title: "Almacenamiento y seguridad",
      content: `Tus datos se almacenan en servidores seguros alojados en Fly.io. Aplicamos las siguientes medidas de seguridad:

• Transmisión cifrada mediante HTTPS/TLS en todas las comunicaciones.
• Autenticación mediante tokens JWT con secreto de servidor.
• Contraseñas almacenadas con hash criptográfico seguro, nunca en texto plano.
• Acceso a la base de datos restringido exclusivamente al personal autorizado de Grupo Bastión.`,
    },
    {
      num: "04",
      title: "Servicios de terceros",
      content: `balu utiliza los siguientes servicios de terceros:

• Anthropic (Claude AI) — Importación de PDFs: el contenido de tu estado de cuenta es enviado a la API de Anthropic para extraer los movimientos. El PDF no es almacenado por balu tras la importación.

• Anthropic (Claude AI) — Insight del dashboard: datos agregados del mes (totales y tu primer nombre) son enviados a Anthropic. No se envían movimientos individuales.

• Fly.io — Infraestructura de servidor: nuestro backend está alojado en servidores de Fly.io.

• Google Play / App Store — Pagos: las suscripciones son procesadas por la tienda donde descargaste la app.

⚠️ Si no deseas que tu PDF sea procesado por Anthropic, simplemente no uses la función de importación. Todos los demás registros son manuales.`,
    },
    {
      num: "05",
      title: "Exportación de datos y archivos locales",
      content: `balu te permite exportar tus datos financieros en formato Excel directamente a tu dispositivo. Este proceso es completamente local — el archivo se genera en tu dispositivo y no pasa por nuestros servidores.

La función de selección de archivos accede únicamente al archivo que tú seleccionas explícitamente. balu no tiene acceso al resto de tus archivos.`,
    },
    {
      num: "06",
      title: "Notificaciones",
      content: `Las notificaciones de balu son completamente locales — se programan directamente en tu dispositivo y no pasan por nuestros servidores. No recopilamos ni almacenamos tokens de notificación push.

Puedes activar o desactivar los recordatorios en cualquier momento desde Ajustes dentro de la app.`,
    },
    {
      num: "07",
      title: "Retención de datos",
      content: `Conservamos tu información mientras tu cuenta esté activa. Si cancelas tu suscripción o eliminas tu cuenta:

• Tus datos financieros son eliminados de nuestros servidores activos en un plazo de 30 días.
• Los registros de facturación se conservan conforme a los requisitos fiscales mexicanos (hasta 5 años).`,
    },
    {
      num: "08",
      title: "Tus derechos (LFPDPPP)",
      content: `Conforme a la Ley Federal de Protección de Datos Personales en Posesión de los Particulares, tienes derecho a Acceso, Rectificación, Cancelación y Oposición (derechos ARCO) sobre tus datos personales.

Para ejercerlos, escríbenos a privacidad@grupobastión.com con el asunto "Derechos ARCO". Responderemos en un plazo máximo de 20 días hábiles.

Adicionalmente, puedes eliminar tu cuenta y todos tus datos directamente desde la app en Ajustes.`,
    },
    {
      num: "09",
      title: "Menores de edad",
      content: `balu no está dirigida a menores de 18 años. No recopilamos conscientemente información de menores. Si detectamos que un usuario es menor de edad, procederemos a eliminar su cuenta y datos asociados.`,
    },
    {
      num: "10",
      title: "Cambios a esta política",
      content: `Podemos actualizar esta política ocasionalmente. Cuando lo hagamos, notificaremos los cambios relevantes mediante una notificación en la app o por correo electrónico, con al menos 15 días de anticipación para cambios materiales.`,
    },
  ];

  return (
    <>
      {/* Nav simple */}
      <nav style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        background: "rgba(10,10,10,0.9)", backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)", height: 60,
        display: "flex", alignItems: "center",
      }}>
        <div style={{ ...S.container, display: "flex", alignItems: "center", gap: 12, width: "100%" }}>
          <a href="/" style={{ display: "flex", alignItems: "center", gap: 8, textDecoration: "none" }}>
            <div style={{ width: 28, height: 28, background: "linear-gradient(135deg, #10B981, #059669)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>🐻</div>
            <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#F5F5F0", fontSize: 16 }}>balu</span>
          </a>
          <span style={{ color: "#6B6B63", fontSize: 13 }}>/ Política de Privacidad</span>
        </div>
      </nav>

      <main style={{ paddingTop: 100, paddingBottom: 80 }}>
        <div style={S.container}>
          {/* Header */}
          <div style={{ textAlign: "center", marginBottom: 56 }}>
            <span style={{ display: "inline-block", background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)", color: "#6EE7B7", fontSize: 11, fontWeight: 700, padding: "4px 12px", borderRadius: 100, marginBottom: 16, letterSpacing: "1px", fontFamily: "'Syne', sans-serif" }}>
              VIGENTE DESDE ENERO 2026
            </span>
            <h1 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(32px, 5vw, 48px)", fontWeight: 800, letterSpacing: "-1.5px", marginBottom: 16 }}>
              Política de Privacidad
            </h1>
            <p style={{ fontSize: 16, color: "#A3A39B", lineHeight: 1.6 }}>
              balu — App de finanzas personales desarrollada por <strong style={{ color: "#F5F5F0" }}>Grupo Bastión</strong>
            </p>
          </div>

          {/* Intro */}
          <div style={{
            background: "#111111",
            border: "1px solid rgba(16,185,129,0.15)",
            borderRadius: 16,
            padding: 24,
            marginBottom: 32,
          }}>
            <p style={{ fontSize: 15, color: "#A3A39B", lineHeight: 1.7 }}>
              En <strong style={{ color: "#F5F5F0" }}>balu</strong>, desarrollada por <strong style={{ color: "#F5F5F0" }}>Grupo Bastión</strong> con sede en Saltillo, Coahuila, México, nos tomamos muy en serio la privacidad de tus datos. Esta política explica qué información recopilamos, cómo la usamos y qué derechos tienes sobre ella.
            </p>
          </div>

          {/* Sections */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {sections.map((section, i) => (
              <div key={i} style={{
                background: "#111111",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: 16,
                padding: "24px 28px",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                  <div style={{
                    width: 28, height: 28,
                    background: "#10B981",
                    borderRadius: "50%",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 11, fontWeight: 800, color: "#fff",
                    fontFamily: "'Syne', sans-serif",
                    flexShrink: 0,
                  }}>
                    {section.num}
                  </div>
                  <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 17, fontWeight: 700, color: "#F5F5F0" }}>
                    {section.title}
                  </h2>
                </div>
                <div style={{ paddingLeft: 40 }}>
                  {section.content.split("\n\n").map((para, j) => (
                    <p key={j} style={{ fontSize: 14, color: "#A3A39B", lineHeight: 1.7, marginBottom: j < section.content.split("\n\n").length - 1 ? 12 : 0, whiteSpace: "pre-line" }}>
                      {para}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Contact */}
          <div style={{
            background: "rgba(16,185,129,0.06)",
            border: "1px solid rgba(16,185,129,0.2)",
            borderRadius: 16,
            padding: 28,
            marginTop: 32,
            textAlign: "center",
          }}>
            <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 16, fontWeight: 700, color: "#10B981", marginBottom: 8 }}>
              ¿Tienes preguntas sobre privacidad?
            </p>
            <p style={{ fontSize: 14, color: "#6EE7B7", marginBottom: 4 }}>
              Escríbenos a <a href="mailto:privacidad@grupobastión.com" style={{ color: "#10B981" }}>privacidad@grupobastión.com</a>
            </p>
            <p style={{ fontSize: 13, color: "#6B6B63" }}>Grupo Bastión — Saltillo, Coahuila, México</p>
          </div>
        </div>
      </main>

      <footer style={{ borderTop: "1px solid rgba(255,255,255,0.05)", padding: "24px 0", textAlign: "center" }}>
        <p style={{ fontSize: 12, color: "#6B6B63" }}>
          © 2026 Grupo Bastión. Todos los derechos reservados. balu es una marca de Grupo Bastión.
        </p>
      </footer>
    </>
  );
}
