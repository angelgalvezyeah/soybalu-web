"use client";

import "./globals.css";
import { useState } from "react";

// ─── Inline styles helpers ────────────────────────────────────────────────
const S = {
  container: {
    maxWidth: 1120,
    margin: "0 auto",
    padding: "0 24px",
  } as React.CSSProperties,
  section: {
    padding: "100px 0",
    position: "relative" as const,
  } as React.CSSProperties,
};

// ─── Nav ──────────────────────────────────────────────────────────────────
function Nav() {
  return (
    <nav style={{
      position: "fixed",
      top: 0, left: 0, right: 0,
      zIndex: 100,
      background: "rgba(10,10,10,0.85)",
      backdropFilter: "blur(20px)",
      borderBottom: "1px solid rgba(255,255,255,0.06)",
    }}>
      <div style={{ ...S.container, display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>
        <a href="/" style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 34, height: 34,
            background: "linear-gradient(135deg, #10B981, #059669)",
            borderRadius: 10,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 18,
          }}>🐻</div>
          <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 20, color: "#F5F5F0", letterSpacing: "-0.5px" }}>
            balu
          </span>
        </a>

        <div style={{ display: "flex", alignItems: "center", gap: 32 }}>
          {[
            { label: "Cómo funciona", href: "#como-funciona" },
            { label: "Características", href: "#caracteristicas" },
            { label: "Precios", href: "#precios" },
            { label: "IA", href: "#ia" },
          ].map((l, i) => (
            <NavLink key={i} href={l.href}>{l.label}</NavLink>
          ))}
        </div>

        <a href="#precios" style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 8,
          background: "#10B981",
          color: "#fff",
          fontFamily: "'Syne', sans-serif",
          fontWeight: 700,
          fontSize: 14,
          padding: "10px 20px",
          borderRadius: 14,
          border: "none",
          cursor: "pointer",
          textDecoration: "none",
        }}>
          Empezar gratis
        </a>
      </div>
    </nav>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  const [hover, setHover] = useState(false);
  return (
    <a href={href}
      style={{ color: hover ? "#10B981" : "#A3A39B", fontSize: 14, fontWeight: 500, textDecoration: "none", transition: "color 0.2s" }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >{children}</a>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────
function Hero() {
  return (
    <section style={{
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      position: "relative",
      overflow: "hidden",
      paddingTop: 64,
    }}>
      <div style={{
        position: "absolute", top: "10%", left: "5%",
        width: 600, height: 600,
        background: "radial-gradient(circle, rgba(16,185,129,0.12) 0%, transparent 70%)",
        borderRadius: "50%",
        pointerEvents: "none",
      }} />
      <div style={{
        position: "absolute", bottom: "10%", right: "5%",
        width: 400, height: 400,
        background: "radial-gradient(circle, rgba(16,185,129,0.07) 0%, transparent 70%)",
        borderRadius: "50%",
        pointerEvents: "none",
      }} />
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)",
        backgroundSize: "60px 60px",
        pointerEvents: "none",
      }} />

      <div style={{ ...S.container, textAlign: "center", position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 28 }}>
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 6,
            background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)",
            color: "#6EE7B7", fontSize: 12, fontWeight: 700, letterSpacing: "0.5px",
            padding: "5px 12px", borderRadius: 100, fontFamily: "'Syne', sans-serif",
          }}>
            🇲🇽 Hecho para México
          </span>
        </div>

        <h1 style={{
          fontFamily: "'Syne', sans-serif",
          fontSize: "clamp(42px, 7vw, 88px)",
          fontWeight: 800,
          lineHeight: 1.05,
          letterSpacing: "-2px",
          marginBottom: 28,
          animation: "fadeUp 0.7s ease 0.1s both",
        }}>
          Tus finanzas,<br />
          <span style={{ background: "linear-gradient(135deg, #10B981 0%, #6EE7B7 50%, #34D399 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
            por fin claras.
          </span>
        </h1>

        <p style={{
          fontSize: "clamp(16px, 2vw, 20px)",
          color: "#A3A39B",
          maxWidth: 520,
          margin: "0 auto 40px",
          lineHeight: 1.6,
          fontWeight: 400,
          animation: "fadeUp 0.7s ease 0.2s both",
        }}>
          balu te dice exactamente cuánto tienes, cuánto debes y en qué se va tu dinero. Sin complicaciones, sin trucos contables.
        </p>

        <div style={{
          display: "flex",
          gap: 12,
          justifyContent: "center",
          flexWrap: "wrap",
          animation: "fadeUp 0.7s ease 0.3s both",
          marginBottom: 60,
        }}>
          <a href="#precios" style={{
            display: "inline-flex", alignItems: "center", gap: 8,
            background: "#10B981", color: "#fff",
            fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 16,
            padding: "16px 32px", borderRadius: 14, textDecoration: "none",
            boxShadow: "0 12px 32px rgba(16,185,129,0.3)",
          }}>
            📱 Descargar ahora
          </a>
          <a href="#como-funciona" style={{
            display: "inline-flex", alignItems: "center", gap: 8,
            background: "transparent", color: "#A3A39B",
            fontSize: 16, padding: "16px 28px", borderRadius: 14,
            border: "1px solid rgba(255,255,255,0.1)", textDecoration: "none",
          }}>
            Ver cómo funciona →
          </a>
        </div>

        <div style={{ animation: "fadeUp 0.9s ease 0.4s both", maxWidth: 700, margin: "0 auto" }}>
          <DashboardMock />
        </div>
      </div>
    </section>
  );
}

function DashboardMock() {
  return (
    <div style={{
      background: "linear-gradient(135deg, #0D1F17 0%, #111111 100%)",
      border: "1px solid rgba(16,185,129,0.2)",
      borderRadius: 24,
      padding: "28px 28px 24px",
      boxShadow: "0 40px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(16,185,129,0.08)",
      textAlign: "left",
      position: "relative",
      overflow: "hidden",
    }}>
      <div style={{ position: "absolute", top: 0, left: "20%", right: "20%", height: 1, background: "linear-gradient(90deg, transparent, rgba(16,185,129,0.5), transparent)" }} />

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <p style={{ fontSize: 12, color: "#6B6B63", marginBottom: 2, fontWeight: 600, letterSpacing: "0.5px" }}>ABRIL 2026</p>
          <p style={{ fontSize: 14, color: "#A3A39B", fontWeight: 500 }}>Hola, Ángel 👋</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {["#EF4444", "#F59E0B", "#10B981"].map((c, i) => (
            <div key={i} style={{ width: 10, height: 10, borderRadius: "50%", background: c, opacity: 0.7 }} />
          ))}
        </div>
      </div>

      <div style={{ marginBottom: 24 }}>
        <p style={{ fontSize: 11, color: "#10B981", fontWeight: 700, letterSpacing: "1px", marginBottom: 4 }}>↑ AHORRASTE ESTE MES</p>
        <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 44, fontWeight: 800, color: "#F5F5F0", letterSpacing: "-2px", lineHeight: 1 }}>
          $3,240<span style={{ fontSize: 24, color: "#6B6B63" }}>.00</span>
        </p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 24 }}>
        {[
          { label: "ENTRÓ", value: "$18,500", color: "#10B981" },
          { label: "SALIÓ", value: "$15,260", color: "#EF4444" },
        ].map((s, i) => (
          <div key={i} style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 14,
            padding: "14px 16px",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: s.color }} />
              <p style={{ fontSize: 9, color: "#6B6B63", fontWeight: 800, letterSpacing: "0.8px" }}>{s.label}</p>
            </div>
            <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 20, fontWeight: 800, color: s.color, letterSpacing: "-0.5px" }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {[
          { name: "Comida", amount: "$3,800", pct: 72, color: "#FF5C00", emoji: "🍔" },
          { name: "Transporte", amount: "$1,200", pct: 45, color: "#8B5CF6", emoji: "🚗" },
          { name: "Entretenimiento", amount: "$800", pct: 30, color: "#0EA5E9", emoji: "🎬" },
        ].map((e, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 32, height: 32, background: `${e.color}22`, borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, flexShrink: 0 }}>
              {e.emoji}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                <span style={{ fontSize: 12, color: "#A3A39B", fontWeight: 500 }}>{e.name}</span>
                <span style={{ fontSize: 12, color: e.color, fontWeight: 700 }}>{e.amount}</span>
              </div>
              <div style={{ height: 4, background: "rgba(255,255,255,0.06)", borderRadius: 4, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${e.pct}%`, background: e.color, borderRadius: 4 }} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 20, padding: "12px 16px", background: "rgba(16,185,129,0.07)", border: "1px solid rgba(16,185,129,0.15)", borderRadius: 12, display: "flex", alignItems: "flex-start", gap: 10 }}>
        <div style={{ fontSize: 22, lineHeight: 1, flexShrink: 0 }}>🐻</div>
        <p style={{ fontSize: 12, color: "#6EE7B7", lineHeight: 1.5, fontStyle: "italic" }}>
          "Este mes bajaste tus gastos de comida 18% vs el anterior. ¡Buen trabajo! 🎉"
        </p>
      </div>
    </div>
  );
}

// ─── Ticker ───────────────────────────────────────────────────────────────
function Ticker() {
  const items = ["Dashboard en tiempo real", "Importar PDF con IA", "Presupuestos mensuales", "Gastos recurrentes", "Exportar a Excel", "Saldos iniciales", "Insights de IA", "Finanzas compartidas", "Papelera de datos"];
  const doubled = [...items, ...items];
  return (
    <div style={{ overflow: "hidden", borderTop: "1px solid rgba(255,255,255,0.05)", borderBottom: "1px solid rgba(255,255,255,0.05)", padding: "16px 0", background: "#0D0D0D" }}>
      <div style={{ display: "flex", animation: "ticker 28s linear infinite", width: "max-content" }}>
        {doubled.map((item, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 24, padding: "0 24px", whiteSpace: "nowrap" }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#10B981", flexShrink: 0, display: "inline-block" }} />
            <span style={{ fontSize: 13, color: "#6B6B63", fontWeight: 500, letterSpacing: "0.3px" }}>{item}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── How It Works ─────────────────────────────────────────────────────────
function HowItWorks() {
  const steps = [
    { num: "01", emoji: "🏦", title: "Configura tus cuentas", desc: "Agrega tus cuentas de banco, efectivo, tarjetas y deudas. Balu te guía paso a paso en menos de 3 minutos.", color: "#0EA5E9" },
    { num: "02", emoji: "📝", title: "Registra tus movimientos", desc: "Anota gastos, ingresos y transferencias con 3 toques. O importa tu estado de cuenta en PDF y la IA hace el trabajo.", color: "#10B981" },
    { num: "03", emoji: "💰", title: "Establece saldos iniciales", desc: "Dile a balu exactamente cuánto tienes hoy en cada cuenta. Así los reportes son 100% precisos desde el primer día.", color: "#F59E0B" },
    { num: "04", emoji: "📊", title: "Entiende tu dinero", desc: "Dashboard, estadísticas, presupuestos y export a Excel. Balu convierte tus datos en decisiones inteligentes.", color: "#8B5CF6" },
  ];

  return (
    <section id="como-funciona" style={S.section}>
      <div style={S.container}>
        <div style={{ textAlign: "center", marginBottom: 64 }}>
          <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 11, fontWeight: 700, letterSpacing: "2px", color: "#10B981", textTransform: "uppercase", marginBottom: 12 }}>Cómo funciona</p>
          <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(32px, 5vw, 52px)", fontWeight: 800, letterSpacing: "-1.5px", lineHeight: 1.1 }}>
            De cero a control total<br />
            <span style={{ background: "linear-gradient(135deg, #10B981, #6EE7B7)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>en 4 pasos.</span>
          </h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 20 }}>
          {steps.map((step, i) => (
            <StepCard key={i} step={step} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StepCard({ step }: { step: { num: string; emoji: string; title: string; desc: string; color: string } }) {
  const [hover, setHover] = useState(false);
  return (
    <div
      style={{
        background: hover ? "#161616" : "#111111",
        border: `1px solid ${hover ? `${step.color}30` : "rgba(255,255,255,0.07)"}`,
        borderRadius: 20,
        padding: 28,
        position: "relative",
        overflow: "hidden",
        transform: hover ? "translateY(-3px)" : "none",
        transition: "all 0.2s ease",
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <div style={{ position: "absolute", top: -10, right: 16, fontFamily: "'Syne', sans-serif", fontSize: 80, fontWeight: 800, color: `${step.color}08`, lineHeight: 1, pointerEvents: "none", userSelect: "none" }}>
        {step.num}
      </div>
      <div style={{ width: 52, height: 52, background: `${step.color}18`, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, marginBottom: 20 }}>
        {step.emoji}
      </div>
      <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 11, color: step.color, fontWeight: 700, letterSpacing: "1px", marginBottom: 8 }}>PASO {step.num}</p>
      <h3 style={{ fontFamily: "'Syne', sans-serif", fontSize: 18, fontWeight: 700, color: "#F5F5F0", marginBottom: 10, letterSpacing: "-0.3px" }}>{step.title}</h3>
      <p style={{ fontSize: 14, color: "#A3A39B", lineHeight: 1.6 }}>{step.desc}</p>
    </div>
  );
}

// ─── Features ─────────────────────────────────────────────────────────────
function Features() {
  const features = [
    { icon: "📊", title: "Dashboard inteligente", desc: "Ve en tiempo real cuánto ahorras, cuánto gastas y dónde va tu dinero. Navega entre meses con un toque.", color: "#10B981", big: true },
    { icon: "🤖", title: "Importar PDF con IA", desc: "Sube tu estado de cuenta y Claude extrae todos los movimientos automáticamente. Tú solo confirmas.", color: "#0EA5E9" },
    { icon: "🎯", title: "Presupuestos mensuales", desc: "Define cuánto quieres gastar en cada categoría. Balu te avisa cuando estás al límite.", color: "#F59E0B" },
    { icon: "🔄", title: "Gastos recurrentes", desc: "Renta, Netflix, gym — configúralos una vez y balu los aplica automáticamente cada mes.", color: "#8B5CF6" },
    { icon: "📈", title: "Estadísticas avanzadas", desc: "Gráficas de ingresos vs gastos, evolución de activos, comparativa año a año y más.", color: "#EC4899" },
    { icon: "📥", title: "Exportar a Excel", desc: "Un toque y tienes tus movimientos del mes en un archivo Excel listo para compartir.", color: "#34D399" },
    { icon: "👥", title: "Finanzas compartidas", desc: "Invita a tu pareja o socio a tu entidad financiera. Decidan juntos con los mismos datos.", color: "#F59E0B" },
    { icon: "🗑️", title: "Papelera de datos", desc: "¿Eliminaste algo por error? No hay drama. Cuentas y movimientos son restaurables en segundos.", color: "#6B7280" },
  ];

  return (
    <section id="caracteristicas" style={{ ...S.section, background: "#0A0A0A" }}>
      <div style={S.container}>
        <div style={{ textAlign: "center", marginBottom: 64 }}>
          <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 11, fontWeight: 700, letterSpacing: "2px", color: "#10B981", textTransform: "uppercase", marginBottom: 12 }}>Características</p>
          <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(32px, 5vw, 52px)", fontWeight: 800, letterSpacing: "-1.5px", lineHeight: 1.1 }}>
            Todo lo que necesitas.<br />
            <span style={{ background: "linear-gradient(135deg, #10B981, #6EE7B7)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>Nada que no.</span>
          </h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 16 }}>
          {features.map((f, i) => (
            <FeatureCard key={i} feature={f} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ feature, index }: { feature: { icon: string; title: string; desc: string; color: string; big?: boolean }; index: number }) {
  const [hover, setHover] = useState(false);
  return (
    <div
      style={{
        background: index === 0
          ? `linear-gradient(135deg, rgba(16,185,129,${hover ? "0.15" : "0.1"}) 0%, rgba(16,185,129,0.03) 100%)`
          : hover ? "#161616" : "#111111",
        border: `1px solid ${index === 0 ? "rgba(16,185,129,0.25)" : hover ? `${feature.color}20` : "rgba(255,255,255,0.06)"}`,
        borderRadius: 20,
        padding: 28,
        display: "flex",
        flexDirection: "column" as const,
        gap: 16,
        transform: hover ? "translateY(-3px)" : "none",
        transition: "all 0.2s ease",
        ...(feature.big ? { gridColumn: "span 2" } : {}),
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <div style={{ width: 48, height: 48, background: `${feature.color}18`, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>
        {feature.icon}
      </div>
      <div>
        <h3 style={{ fontFamily: "'Syne', sans-serif", fontSize: 17, fontWeight: 700, color: "#F5F5F0", marginBottom: 8, letterSpacing: "-0.3px" }}>{feature.title}</h3>
        <p style={{ fontSize: 14, color: "#A3A39B", lineHeight: 1.6 }}>{feature.desc}</p>
      </div>
    </div>
  );
}

// ─── AI Section ───────────────────────────────────────────────────────────
function AISection() {
  return (
    <section id="ia" style={{ ...S.section, background: "#0D0D0D", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 800, height: 800, background: "radial-gradient(circle, rgba(14,165,233,0.06) 0%, transparent 70%)", pointerEvents: "none" }} />
      <div style={{ ...S.container, position: "relative", zIndex: 1 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(14,165,233,0.1)", border: "1px solid rgba(14,165,233,0.2)", color: "#7DD3FC", fontSize: 11, fontWeight: 700, padding: "5px 12px", borderRadius: 100, fontFamily: "'Syne', sans-serif" }}>
                ✨ Powered by Claude AI
              </span>
            </div>
            <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(28px, 4vw, 46px)", fontWeight: 800, letterSpacing: "-1.5px", lineHeight: 1.1, marginBottom: 20 }}>
              La IA que entiende<br />
              <span style={{ background: "linear-gradient(135deg, #0EA5E9, #7DD3FC)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>tus finanzas.</span>
            </h2>
            <p style={{ fontSize: 16, color: "#A3A39B", lineHeight: 1.7, marginBottom: 32 }}>
              balu usa la API de Anthropic (Claude) en dos superpoderes: importar tus estados de cuenta bancarios automáticamente, y generarte un resumen financiero personalizado al final de cada mes.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {[
                { icon: "📄", title: "Importación de PDF", desc: "Sube tu estado de cuenta y Claude extrae todos los movimientos. Detecta gastos, ingresos y transferencias automáticamente." },
                { icon: "💬", title: "Insight mensual", desc: "Al cierre de mes, balu te da un análisis breve y personalizado de cómo estuvo tu situación financiera." },
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", gap: 14, padding: "16px 18px", background: "rgba(14,165,233,0.05)", border: "1px solid rgba(14,165,233,0.12)", borderRadius: 14 }}>
                  <span style={{ fontSize: 22, flexShrink: 0 }}>{item.icon}</span>
                  <div>
                    <p style={{ fontSize: 14, fontWeight: 700, color: "#7DD3FC", marginBottom: 4 }}>{item.title}</p>
                    <p style={{ fontSize: 13, color: "#A3A39B", lineHeight: 1.5 }}>{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
            <p style={{ fontSize: 12, color: "#6B6B63", marginTop: 20, lineHeight: 1.5 }}>
              * La importación de PDF es opcional. Si prefieres registrar todo manualmente, balu funciona igual de bien.
            </p>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ background: "#111111", border: "1px solid rgba(14,165,233,0.2)", borderRadius: 20, padding: 24 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
                <div style={{ width: 40, height: 40, background: "rgba(14,165,233,0.1)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>📄</div>
                <div>
                  <p style={{ fontSize: 13, fontWeight: 700, color: "#F5F5F0" }}>Estado de cuenta BBVA</p>
                  <p style={{ fontSize: 11, color: "#6B6B63" }}>Procesado con Claude AI</p>
                </div>
                <div style={{ marginLeft: "auto", background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: 8, padding: "4px 10px" }}>
                  <span style={{ fontSize: 11, color: "#10B981", fontWeight: 700 }}>✓ Listo</span>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {[
                  { desc: "Oxxo • Comida", amount: "-$85.00", color: "#EF4444" },
                  { desc: "SPEI recibido • Sueldo", amount: "+$18,500", color: "#10B981" },
                  { desc: "Spotify • Suscripción", amount: "-$99.00", color: "#EF4444" },
                  { desc: "Pago TDC BBVA", amount: "-$3,500", color: "#8B5CF6" },
                ].map((tx, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: "rgba(255,255,255,0.03)", borderRadius: 10 }}>
                    <div style={{ width: 28, height: 28, background: `${tx.color}18`, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <div style={{ width: 8, height: 8, borderRadius: "50%", background: tx.color }} />
                    </div>
                    <span style={{ fontSize: 12, color: "#A3A39B", flex: 1 }}>{tx.desc}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: tx.color }}>{tx.amount}</span>
                  </div>
                ))}
                <p style={{ fontSize: 11, color: "#6B6B63", textAlign: "center", marginTop: 4 }}>+ 23 movimientos más detectados</p>
              </div>
            </div>

            <div style={{ background: "#111111", border: "1px solid rgba(16,185,129,0.15)", borderRadius: 20, padding: 20, display: "flex", gap: 14, alignItems: "flex-start" }}>
              <div style={{ fontSize: 36, lineHeight: 1 }}>🐻</div>
              <div>
                <p style={{ fontSize: 11, color: "#10B981", fontWeight: 700, letterSpacing: "0.5px", marginBottom: 6 }}>RESUMEN IA — ABRIL 2026</p>
                <p style={{ fontSize: 13, color: "#D1FAE5", lineHeight: 1.6, fontStyle: "italic" }}>
                  "Ahorraste $3,240 este mes — tu mejor resultado del trimestre. El gasto en restaurantes bajó 22%. ¡Sigue así! 🎉"
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Pricing ──────────────────────────────────────────────────────────────
function Pricing() {
  const liteFeatures = ["Dashboard mensual completo", "Registro ilimitado de movimientos", "Importación de PDFs con IA", "Presupuestos y recurrentes", "Exportar a Excel", "Estadísticas básicas", "1 entidad financiera"];
  const proFeatures = ["Todo lo de Lite", "Múltiples entidades", "Finanzas compartidas con invitados", "Estadísticas avanzadas (año a año)", "Insight de IA mensual personalizado", "Soporte prioritario", "Acceso anticipado a funciones nuevas"];

  return (
    <section id="precios" style={{ ...S.section, background: "#0A0A0A" }}>
      <div style={S.container}>
        <div style={{ textAlign: "center", marginBottom: 64 }}>
          <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 11, fontWeight: 700, letterSpacing: "2px", color: "#10B981", textTransform: "uppercase", marginBottom: 12 }}>Precios</p>
          <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(32px, 5vw, 52px)", fontWeight: 800, letterSpacing: "-1.5px", lineHeight: 1.1, marginBottom: 16 }}>
            Elige tu plan.
          </h2>
          <p style={{ fontSize: 16, color: "#A3A39B" }}>Cancela cuando quieras. Sin compromisos.</p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, maxWidth: 800, margin: "0 auto" }}>
          {/* Lite */}
          <PlanCard
            name="BALU LITE"
            price="$69"
            period="/mes"
            annual="o $499/año — ahorra $329"
            features={liteFeatures}
            featured={false}
            cta="Empezar con Lite"
          />
          {/* Pro */}
          <PlanCard
            name="BALU PRO"
            price="$129"
            period="/mes"
            annual="o $999/año — ahorra $549"
            features={proFeatures}
            featured={true}
            cta="Empezar con Pro"
            badge="POPULAR"
          />
        </div>

        <p style={{ textAlign: "center", fontSize: 13, color: "#6B6B63", marginTop: 32 }}>
          Precios en MXN. Cobro a través de App Store o Google Play. Cancela cuando quieras.
        </p>
      </div>
    </section>
  );
}

function PlanCard({ name, price, period, annual, features, featured, cta, badge }: {
  name: string; price: string; period: string; annual: string;
  features: string[]; featured: boolean; cta: string; badge?: string;
}) {
  const [hover, setHover] = useState(false);
  return (
    <div
      style={{
        background: featured
          ? `linear-gradient(135deg, rgba(16,185,129,${hover ? "0.15" : "0.12"}) 0%, rgba(16,185,129,0.04) 100%)`
          : hover ? "#161616" : "#111111",
        border: `1px solid ${featured ? "rgba(16,185,129,0.3)" : "rgba(255,255,255,0.07)"}`,
        borderRadius: 20,
        padding: 28,
        position: "relative",
        overflow: "hidden",
        transform: hover ? "translateY(-3px)" : "none",
        transition: "all 0.2s ease",
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {badge && (
        <div style={{ position: "absolute", top: 16, right: 16, background: "#10B981", color: "#fff", fontSize: 11, fontWeight: 800, fontFamily: "'Syne', sans-serif", padding: "4px 10px", borderRadius: 100, letterSpacing: "0.5px" }}>
          {badge}
        </div>
      )}
      {featured && <div style={{ position: "absolute", top: 0, left: "20%", right: "20%", height: 1, background: "linear-gradient(90deg, transparent, rgba(16,185,129,0.6), transparent)" }} />}

      <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: featured ? "#10B981" : "#A3A39B", letterSpacing: "1px", marginBottom: 4 }}>{name}</p>
      <div style={{ marginBottom: 8 }}>
        <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 42, fontWeight: 800, color: "#F5F5F0", letterSpacing: "-1.5px" }}>{price}</span>
        <span style={{ fontSize: 14, color: "#6B6B63" }}>{period}</span>
      </div>
      <p style={{ fontSize: 13, color: "#10B981", fontWeight: 600, marginBottom: 28 }}>{annual}</p>

      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 28 }}>
        {features.map((f, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ color: "#10B981", fontSize: 14, flexShrink: 0 }}>✓</span>
            <span style={{ fontSize: 14, color: featured && i === 0 ? "#6EE7B7" : "#A3A39B", fontWeight: featured && i === 0 ? 600 : 400 }}>{f}</span>
          </div>
        ))}
      </div>

      <a href="#" style={{
        display: "block", textAlign: "center", padding: "14px",
        background: featured ? "#10B981" : "transparent",
        color: featured ? "#fff" : "#A3A39B",
        border: featured ? "none" : "1px solid rgba(255,255,255,0.1)",
        borderRadius: 14,
        fontSize: 14, fontFamily: "'Syne', sans-serif", fontWeight: 700,
        textDecoration: "none",
        boxShadow: featured ? "0 8px 24px rgba(16,185,129,0.3)" : "none",
      }}>
        {cta}
      </a>
    </div>
  );
}

// ─── FAQ ─────────────────────────────────────────────────────────────────
function FAQ() {
  const faqs = [
    { q: "¿Es seguro subir mi estado de cuenta?", a: "Sí. Tu PDF se envía directamente a la API de Anthropic (Claude) solo para extraer los movimientos. balu no lo almacena después del procesamiento. Toda la comunicación es cifrada con HTTPS." },
    { q: "¿Necesito conectar mis cuentas bancarias?", a: "No. balu funciona con registro manual y con importación de PDFs. No pedimos acceso a tus cuentas bancarias ni contraseñas. Tú tienes el control total." },
    { q: "¿Puedo usar balu para mi negocio?", a: "balu Pro te permite crear múltiples entidades e invitar colaboradores, lo que lo hace ideal para freelancers y pequeños negocios. Para negocios más complejos, pronto llegará Lynor (nuestro producto B2B)." },
    { q: "¿Qué pasa si cancelo mi suscripción?", a: "Mantienes acceso hasta el fin del período pagado. Después, tu cuenta pasa a modo lectura. Tus datos se eliminan a los 30 días si no reactivas." },
    { q: "¿Funciona en iOS y Android?", a: "Sí. balu está disponible en App Store y Google Play. La experiencia es idéntica en ambas plataformas." },
    { q: "¿Tiene soporte para moneda extranjera?", a: "Cada entidad puede configurarse con su propia moneda (MXN, USD, EUR, etc.). Por ahora los reportes son por entidad — no hay conversión de divisas automática." },
  ];

  return (
    <section style={{ ...S.section, background: "#0D0D0D" }}>
      <div style={{ ...S.container, maxWidth: 720 }}>
        <div style={{ textAlign: "center", marginBottom: 56 }}>
          <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 11, fontWeight: 700, letterSpacing: "2px", color: "#10B981", textTransform: "uppercase", marginBottom: 12 }}>Preguntas frecuentes</p>
          <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(28px, 4vw, 44px)", fontWeight: 800, letterSpacing: "-1.5px" }}>
            Respuestas rápidas.
          </h2>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {faqs.map((faq, i) => (
            <FAQItem key={i} q={faq.q} a={faq.a} />
          ))}
        </div>
      </div>
    </section>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  const [hover, setHover] = useState(false);
  return (
    <div
      style={{
        background: "#111111",
        border: `1px solid ${hover ? "rgba(16,185,129,0.2)" : "rgba(255,255,255,0.06)"}`,
        borderRadius: 16,
        padding: "20px 24px",
        transition: "border-color 0.2s",
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 15, fontWeight: 700, color: "#F5F5F0", marginBottom: 8 }}>{q}</p>
      <p style={{ fontSize: 14, color: "#A3A39B", lineHeight: 1.6 }}>{a}</p>
    </div>
  );
}

// ─── CTA Final ────────────────────────────────────────────────────────────
function CTAFinal() {
  return (
    <section style={{ padding: "80px 0 100px", background: "#0A0A0A", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", width: 600, height: 400, background: "radial-gradient(ellipse, rgba(16,185,129,0.12) 0%, transparent 70%)", pointerEvents: "none" }} />
      <div style={{ ...S.container, textAlign: "center", position: "relative", zIndex: 1 }}>
        <div style={{ marginBottom: 16 }}><span style={{ fontSize: 52 }}>🐻</span></div>
        <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(32px, 5vw, 56px)", fontWeight: 800, letterSpacing: "-1.5px", lineHeight: 1.1, marginBottom: 20 }}>
          ¿Sabes exactamente<br />
          <span style={{ background: "linear-gradient(135deg, #10B981, #6EE7B7)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>cuánto tienes hoy?</span>
        </h2>
        <p style={{ fontSize: 18, color: "#A3A39B", maxWidth: 460, margin: "0 auto 40px", lineHeight: 1.6 }}>
          Con balu, la respuesta siempre es sí.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <a href="#" style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#10B981", color: "#fff", fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 16, padding: "16px 36px", borderRadius: 14, textDecoration: "none", boxShadow: "0 12px 32px rgba(16,185,129,0.35)" }}>
            📱 Descargar balu gratis
          </a>
        </div>
        <p style={{ fontSize: 12, color: "#6B6B63", marginTop: 16 }}>App Store y Google Play · Disponible para México</p>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ borderTop: "1px solid rgba(255,255,255,0.06)", background: "#0A0A0A", padding: "48px 0 32px" }}>
      <div style={S.container}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 40, marginBottom: 48 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
              <div style={{ width: 34, height: 34, background: "linear-gradient(135deg, #10B981, #059669)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🐻</div>
              <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 20, color: "#F5F5F0" }}>balu</span>
            </div>
            <p style={{ fontSize: 13, color: "#6B6B63", lineHeight: 1.6, maxWidth: 260 }}>
              App de finanzas personales hecha en México. Desarrollada por Grupo Bastión, Saltillo, Coahuila.
            </p>
            <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
              <FooterLink href="https://instagram.com/soybalu.app">Instagram</FooterLink>
            </div>
          </div>

          <div>
            <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 12, fontWeight: 700, color: "#A3A39B", letterSpacing: "1px", marginBottom: 16 }}>PRODUCTO</p>
            {["Características", "Precios", "Cómo funciona", "IA"].map((l, i) => (
              <FooterLink key={i} href="#">{l}</FooterLink>
            ))}
          </div>

          <div>
            <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 12, fontWeight: 700, color: "#A3A39B", letterSpacing: "1px", marginBottom: 16 }}>EMPRESA</p>
            {["Grupo Bastión", "Lynor (B2B)", "Contacto"].map((l, i) => (
              <FooterLink key={i} href="#">{l}</FooterLink>
            ))}
          </div>

          <div>
            <p style={{ fontFamily: "'Syne', sans-serif", fontSize: 12, fontWeight: 700, color: "#A3A39B", letterSpacing: "1px", marginBottom: 16 }}>LEGAL</p>
            <FooterLink href="/terminos">Términos y Condiciones</FooterLink>
            <FooterLink href="/privacidad">Política de Privacidad</FooterLink>
          </div>
        </div>

        <div style={{ borderTop: "1px solid rgba(255,255,255,0.05)", paddingTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
          <p style={{ fontSize: 12, color: "#6B6B63" }}>© 2026 Grupo Bastión. Todos los derechos reservados. balu es una marca de Grupo Bastión.</p>
          <p style={{ fontSize: 12, color: "#6B6B63" }}>Hecho con 🐻 en Saltillo, México</p>
        </div>
      </div>
    </footer>
  );
}

function FooterLink({ href, children }: { href: string; children: React.ReactNode }) {
  const [hover, setHover] = useState(false);
  return (
    <a href={href} style={{ display: "block", fontSize: 14, color: hover ? "#A3A39B" : "#6B6B63", textDecoration: "none", marginBottom: 8, transition: "color 0.2s" }}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      {children}
    </a>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────
export default function Page() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Ticker />
        <HowItWorks />
        <Features />
        <AISection />
        <Pricing />
        <FAQ />
        <CTAFinal />
      </main>
      <Footer />
    </>
  );
}
