import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "balu — Tus finanzas personales, por fin claras",
  description:
    "balu es la app de finanzas personales que te dice exactamente cuánto tienes, cuánto debes y en qué se va tu dinero. Registra, importa con IA, presupuesta y exporta.",
  keywords: "finanzas personales, app finanzas mexico, presupuesto, gastos, ingresos, balu",
  authors: [{ name: "Grupo Bastión" }],
  metadataBase: new URL("https://soybalu.app"),
  openGraph: {
    title: "balu — Tus finanzas personales, por fin claras",
    description:
      "Registra tus movimientos, importa estados de cuenta con IA, controla presupuestos y entiende a dónde va tu dinero cada mes.",
    url: "https://soybalu.app",
    siteName: "balu",
    locale: "es_MX",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "balu — Tus finanzas personales, por fin claras",
    description: "La app de finanzas personales hecha para México.",
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ margin: 0, padding: 0, background: "#0A0A0A", color: "#F5F5F0", fontFamily: "'DM Sans', sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
